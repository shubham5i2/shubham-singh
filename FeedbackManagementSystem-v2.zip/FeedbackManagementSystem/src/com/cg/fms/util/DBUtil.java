package com.cg.fms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	static Connection connection=null;
	public static Connection conn(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","oracle");  
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return connection;
	}
}
