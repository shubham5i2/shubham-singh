package com.cg.fms.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cg.fms.bean.Employee;
import com.cg.fms.exception.FeedbackException;

public class UserServiceImplTest {

	@Test
	public void testGetRole() {
		UserServiceImpl service=new UserServiceImpl();
		Employee emp=new Employee();
		emp.setEmployeeId("1000");
		emp.setPassword("admin@123");
		emp.setRole("admin");
		String role="admin";
		assertEquals(role,emp.getRole());
	}

	@Test
	public void testGetEmployeeDetails() throws FeedbackException {
		UserServiceImpl service=new UserServiceImpl();
		int employeeId=1000;
		String employeeName="Admin";
		List<Employee> list=service.getEmployeeDetails(employeeId);
		assertEquals(employeeId, Integer.parseInt(list.get(0).getEmployeeId()));
		assertEquals(employeeName, list.get(0).getEmployeeName());
	}

}
