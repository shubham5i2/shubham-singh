package com.cg.fms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.fms.bean.Course;
import com.cg.fms.exception.FeedbackException;

public class CourseServiceImplTest {
	
	@Test
	public void testDisplayCourseDetails() throws FeedbackException {
		CourseServiceImpl service=new CourseServiceImpl();
		int courseId=501;
		String courseName="Java";
		String duration="45";
		ArrayList<Course> list=service.displayCourseDetails();
		assertEquals(courseId, Integer.parseInt(list.get(0).getCourseId()));
		assertEquals(courseName, list.get(0).getCourseName());
		assertEquals(duration, list.get(0).getNoOfDays());
	}

	@Test
	public void testUpdateCourserDetails() throws FeedbackException {
		CourseServiceImpl service=new CourseServiceImpl();
		String courseId="116";
		String courseName="oraaps";
		String duration="25";
		Course course=new Course();
		course.setCourseName(courseName);
		course.setNoOfDays(duration);
		boolean result=service.updateCourserDetails(courseId, course);
		assertEquals(true,result);
	}

	@Test
	public void testDeleteCourseDetails() throws FeedbackException {
		CourseServiceImpl service=new CourseServiceImpl();
		String courseId="116";
		boolean result=service.deleteCourseDetails(courseId);
		assertEquals(true,result);
	}

}
