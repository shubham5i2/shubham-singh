package com.cg.fms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.cg.fms.bean.Course;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.exception.FeedbackException;

public class TrainingProgramServiceImplTest {

	@Test
	public void testShowTrainerDetails() throws FeedbackException {
		TrainingProgramServiceImpl service=new TrainingProgramServiceImpl();
		int trainingCode=10000;
		int courseCode=501;
		int facultyCode=1001;
		String startDate="09-AUG-18";
		String endDate="09-OCT-18";
		ArrayList<TrainingProgram> list=service.showTrainerDetails();
		assertEquals(trainingCode, list.get(0).getTrainingCode());
		assertEquals(courseCode, list.get(0).getCourseCode());
		assertEquals(facultyCode, list.get(0).getFacultyCode());
		
	}

	
	@Test
	public void testGetCourses() throws FeedbackException {
		TrainingProgramServiceImpl service=new TrainingProgramServiceImpl();
		String courseName="Java";
		String courseId="501";
		List<Course> list=service.getCourses();
		assertEquals(courseName, list.get(0).getCourseName());
		assertEquals(courseId, list.get(0).getCourseId());
	}

}
