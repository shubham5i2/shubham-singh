package com.cg.fms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.fms.bean.FacultySkill;
import com.cg.fms.exception.FeedbackException;

public class FacultySkillServiceImplTest {

	@Test
	public void testShowFacultySkillSet() throws FeedbackException {
		FacultySkillServiceImpl service=new FacultySkillServiceImpl();
		int facultyId=1001;
		String skillSet="Java,C++,MainFrames";
		ArrayList<FacultySkill> list=service.showFacultySkillSet();
		assertEquals(facultyId, list.get(0).getFacultyId());
		assertEquals(skillSet, list.get(0).getSkillSet());
	}

}
