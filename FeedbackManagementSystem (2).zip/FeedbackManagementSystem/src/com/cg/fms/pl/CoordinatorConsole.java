package com.cg.fms.pl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.bean.Course;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.Feedback;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.FacultySkillServiceImpl;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.IFacultySkillService;
import com.cg.fms.service.IFeedbackService;
import com.cg.fms.service.ITrainingProgramService;
import com.cg.fms.service.TrainingProgramServiceImpl;

public class CoordinatorConsole {

	TrainingProgram program = new TrainingProgram();
	ITrainingProgramService trainer= new TrainingProgramServiceImpl();
	IFacultySkillService facultySkillService = new FacultySkillServiceImpl();
	TrainingProgram trainingProgram;
	Scanner scanner = new Scanner(System.in);
	int choice;
	char option;
	int trainingCode = 0;
	public void coordinatorFunctions() throws FeedbackException {
		char value='a';
		List<Course> courseList;
		ITrainingProgramService iTrainer;
		do{
			System.out.println("Select your choice:\n[1].Participant Enrolment\n[2].Training Program Maintainance\n[3].View Feedback\n[4].Exit");
			choice=scanner.nextInt();
			TrainingProgram program = new TrainingProgram();
		    switch (choice)
		    {
		    case 1:
		    	iTrainer= new TrainingProgramServiceImpl();
				System.out.println("Course Details");
				courseList= iTrainer.getCourses();
				for (Course course : courseList) {
					System.out.println(course.getCourseName());
				}
				System.out.println("Enter Participant ID (existing employee):");
				String participantId= scanner.next();
				System.out.println("Enter Course Name (Select from list displayed):");
				String courseName= scanner.next();
				String trainingCode1=iTrainer.enrollParticipant(participantId,courseName);
				if(trainingCode1!=null){
				System.out.println("Participant with Id "+participantId+" enrolled for "+courseName+" with Training code "+trainingCode1);
				}else{
					System.out.println("Sorry!!! Currently no training programs available for Course "+courseName);
				}
				break;
		    case 2:
		    	do{
		    		System.out.println("Select your choice:\n[1].Add Training Details\n[2].Show Training Details\n[3].View Training Details\n[4].Update Training Details\n[5].Delete Training Details\n[6].Go to Main Menu\n[7].Exit");
		    		choice=scanner.nextInt();
		    		
		    		 switch (choice)
		 		    {
		 		    case 1:
		 		    	iTrainer= new TrainingProgramServiceImpl();
						System.out.println("Course Details");
						courseList= iTrainer.getCourses();
						for (Course course : courseList) {
							System.out.println(course.getCourseId()+" "+course.getCourseName());
						}
				        System.out.println("Add Trainer Details");
						System.out.println("Enter Course Code :");
						program.setCourseCode(scanner.nextInt());
						System.out.println("Enter faculty Code :");
						  ArrayList<FacultySkill> facultySkillList = facultySkillService.showFacultySkillSet();
						  for (FacultySkill facultySkill : facultySkillList) {
								/*System.out.println(facultySkill.getFacultyId() + "     "
										+ facultySkill.getSkillSet());*/
							  System.out.println(facultySkill);
						  }
						program.setFacultyCode(scanner.nextInt());
						System.out.println("Enter Start Date : (in format:dd/mm/yyyy)");
						program.setStartDate(scanner.next());
						System.out.println("Enter End Date : (in format:dd/mm/yyyy)");
						program.setEndDate(scanner.next());
						
						try{
								String trainingCode=trainer.addTrainer(program);
				      if(trainingCode!=null){
				    	  System.out.println("Your data successfully entered");
				    	  System.out.println("Training program registered successfully with Training code "+trainingCode);
				      }
				      else{
				    	  System.out.println("Error while inserting Training Program details");
				      }}
							catch(Exception ex){
								System.err.println(ex.getMessage());
								
							}
				      break;
				     
		 		    case 2:
		 				  ArrayList<TrainingProgram> trainerList = trainer.showTrainerDetails();
		 				  for (TrainingProgram trainingDetails : trainerList) {
		 						/*System.out.println(bean.getTrainingCode() + "     "
		 								+ bean.getCourseCode()+ "      "
		 								+ bean.getFacultyCode()+ "      "
		 								+bean.getStartDate()+"     "
		 								+ bean.getEndDate());*/
		 					  System.out.println(trainingDetails);
		 					  
		 					}

		 				  break;
		 				  
		 		   case 3:
				    	System.out.println("Enter Training Code");
				    	trainingCode=scanner.nextInt();
				    	trainingProgram=trainer.viewTrainerDetails(trainingCode);
				    	if(trainingProgram.getTrainingCode()!=0){
				    	/*System.out.println(trainingProgram.getTrainingCode()+" "+trainingProgram.getCourseCode()+" "+trainingProgram.getFacultyCode()+" "+trainingProgram.getStartDate()+" "+trainingProgram.getEndDate());*/
				    	System.out.println(trainingProgram);
				    	}else{
				    		System.out.println("Trainig Code "+trainingCode+" does not exist!!!");
				    	}
				    	break;
				    
		 		   case 4:
		 			  System.out.println("Enter Training Code");
		 		    	trainingCode=scanner.nextInt();
		 		    	System.out.println("Training Program details with training code "+ trainingCode +" are");
		 		    	
		 		    	trainingProgram=trainer.viewTrainerDetails(trainingCode);
				    	if(trainingProgram.getTrainingCode()!=0){
				    	/*System.out.println(trainingProgram.getTrainingCode()+" "+trainingProgram.getCourseCode()+" "+trainingProgram.getFacultyCode()+" "+trainingProgram.getStartDate()+" "+trainingProgram.getEndDate());*/
				    		System.out.println(trainingProgram);
				    	}else{
				    		System.out.println("Trainig Code "+trainingCode+" does not exist!!!");
				    	}
		 		    	
		 				try{
		 					if(trainingProgram!=null){
		 						System.out.println("Enter faculty Code :");
				 		    	int facultyCode = scanner.nextInt();
				 		    	program.setFacultyCode(facultyCode);
				 		    	System.out.println("Enter Start Date : (in format:dd/mm/yyyy)");
								program.setStartDate(scanner.next());
								System.out.println("Enter End Date : (in format:dd/mm/yyyy)");
								program.setEndDate(scanner.next());
				 				int result=trainer.updateTrainerDetails(trainingCode,program);
				 				 if(result!=0){
				 			    	  System.out.println("Training program details with Training code "+trainingCode+" has been updated!!!");
				 			      }
				 			      else{
				 			    	  System.out.println("Error while updating Training program details");
				 			      }
				 				}}
				 						catch(Exception e1){
				 							System.err.println(e1.getMessage());
				 							
				 						}

		 			   break;
				    case 5:
				    	System.out.println("Enter Training Code");
				    	trainingCode = scanner.nextInt();
				    	trainingProgram=trainer.viewTrainerDetails(trainingCode);
				    	if(trainingProgram.getTrainingCode()!=0){
				    	/*System.out.println(trainingProgram.getTrainingCode()+" "+trainingProgram.getCourseCode()+" "+trainingProgram.getFacultyCode()+" "+trainingProgram.getStartDate()+" "+trainingProgram.getEndDate());*/
				    	System.out.println(trainingProgram);
				    	}else{
				    		System.out.println("Trainig Code "+trainingCode+" does not exist!!!");
				    	}
				    	if(trainingProgram.getCourseCode()!=0){
				    		System.out.println("Enter YES to delete the training program");
				    		String delete = scanner.next();
				    		if(delete.equalsIgnoreCase("YES")){
				    	boolean flag=trainer.deleteTrainerDetails(trainingCode);
				    	if(flag){
				    		System.out.println("Training Program details with Id "+trainingCode+" has been deleted");
				    	}
				    	
				    	else{
				    		System.out.println("Error in deleting training program details");
				    	}}
				    		else{
				    			System.out.println("Delete operation for training program with training code "+trainingCode+" is not confirmed");
				    		}}
				    	break;
				    case 6:
				    	
				    	coordinatorFunctions();
				    	break;
				    	
				    case 7:
				    	System.out.println("Exit");
				    	System.exit(0);
						break;
						
				    default:
				      System.out.println("Enter correct Choice.!!");
		    	}
		    		 System.out.println("Do you Want to Continue (Y) :");
		 		    option=scanner.next().charAt(0);
		    	}while(option== 'Y' || option=='y');
		    	
		    case 3:
		    	System.out.println("Feedback Reports");
				IFeedbackService iFeedbackService = new FeedbackServiceImpl();
				
			do{
				System.out.println("\nSelect the feedback view type:");
				System.out.println("[1]View Feedback of all");
				System.out.println("[2]View Feedback by Training Code");
				//System.out.println("[3]View Feedback entered on a particular date");
				System.out.println("[4]Go to Main Menu");
				System.out.println("[5]Exit");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					ArrayList<Feedback> feedbackList = iFeedbackService.showFeedback();
					  for (Feedback feedbackdetails : feedbackList) {
						  System.out.println(feedbackdetails);
						 /* System.out.println(feedbackdetails.getTrainingCode()
								    +"    "+feedbackdetails.getParticipantId()
								    +"    "+feedbackdetails.getParticipantName()
									+"    "+feedbackdetails.getFbPrsComm()
									+"    "+feedbackdetails.getFbClrfyDbts()
									+"    "+feedbackdetails.getFbTm()
									+"    "+feedbackdetails.getFbHndOut()
									+"    "+feedbackdetails.getComments()
									+"    "+feedbackdetails.getSuggestions()
									+"    "+feedbackdetails.getFeedbackDate());*/
						}
						
				break;
					
				case 2:
					System.out.println("Enter the training code");
					Feedback feedback = new Feedback();
					int trainingcode = scanner.nextInt();
					List<Feedback> feedBackListById = iFeedbackService.getFeedBack(trainingcode);
					List<Float> averageList = new ArrayList<Float>();
					averageList=iFeedbackService.getAverages(feedBackListById);
					for (Feedback feedbackDetailsById : feedBackListById) {
					
							if(feedbackDetailsById.getTrainingCode()!=0){
							
								System.out.println(feedbackDetailsById);	
	}				
					
					else
					{
						System.out.println("The Feedback details with the training Id "+trainingcode+" does not exist.Enter a valid training Id.");
					}}
					
					System.out.println("ClarifyingDoubts  Handout Given   Soft/Hard Conn.   Communication   Time Manag.");
					for (Float float1 : averageList) {
						System.out.print(float1);
						System.out.print("\t  ");
					}
					System.out.println("\n");
					
					break;
				
							
			/*	case 3:
					System.out.println("Enter Feedback Date : (in format:dd/mm/yyyy)");
					String date = scanner.next();
					try {
						List<Feedback> feedBackList = iFeedbackService.getFeedBackByDate(date);
						for (Feedback feedbackByDate : feedBackList) {
					if(feedbackByDate.getTrainingCode()!=0){
						
					System.out.println(feedbackByDate);
					}
						else
						{
							System.out.println("Enter valid date");
						}
						}
					} catch (FeedbackException e) {
						e.printStackTrace();
					}
					break;*/
				case 3:
			    	
					adminFunctions();
			    	break;
				case 4:
					System.out.println("Exit");
			    	System.exit(0);
					break;
					
				default:
					System.out.println("Enter correct choice");
					
				}
				System.out.println("Do you want to continue enter Y:");
				 value = scanner.next().charAt(0);

				} while (value == 'Y' || value == 'y');

				scanner.close();		
		
				break;
		    case 4:
		    	System.out.println("Exit");
		    	System.exit(0);
				break;
				
		    default:
		      System.out.println("Enter correct Choice.!!");

		    }
		    System.out.println("Do you Want to Continue (Y) :");
		    option=scanner.next().charAt(0);
			}while(option== 'Y'|| option=='y');

			}
	private void adminFunctions() {
		// TODO Auto-generated method stub
		
	}
}
	
