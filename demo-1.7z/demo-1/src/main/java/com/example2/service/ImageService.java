package com.example2.service;

import java.io.IOException;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example2.entity.ImageEntity;
import com.example2.repository.IMongoRepository;

@Service
public class ImageService {
	
	@Autowired
	IMongoRepository iMongoRepository;
	
	public String addPhoto(String title, MultipartFile file) throws IOException { 
        ImageEntity photo = new ImageEntity(title);
        photo.setImage(new Binary(BsonBinarySubType.BINARY, file.getBytes())); 
        photo = iMongoRepository.insert(photo);
        return "Image Added to DB";
	}
    }
 
	


