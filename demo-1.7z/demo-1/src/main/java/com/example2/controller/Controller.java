package com.example2.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.example2.service.ImageService;

@RestController
public class Controller {
	
	@Autowired
	ImageService imageService;

	@PostMapping("/photos/add")
	public String addPhoto(@RequestParam("title") String title, 
	  @RequestParam("image") MultipartFile image, Model model) 
	  throws IOException {
		System.out.println("In ADD PHOTO");
	    return imageService.addPhoto(title, image);
	}
	
	@PostMapping("/home")
	public String home() {
		System.out.println("IN HOME");
		return "HOME";
		
	}
	
}