package com.example2.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example2.entity.ImageEntity;

@Repository
public interface IMongoRepository extends MongoRepository<ImageEntity, String> {
	

}
