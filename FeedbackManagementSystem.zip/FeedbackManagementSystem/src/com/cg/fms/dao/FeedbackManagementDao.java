package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.exception.CourseException;
import com.cg.fms.util.DBUtil;

public class FeedbackManagementDao implements IFeedbackManagementDao{

	boolean value=false;
	static Connection connection=null;
	PreparedStatement preparedStatement=null;
	PreparedStatement preparedStatement1=null;
	PreparedStatement preparedStatement2=null;
	ResultSet resultSet=null;
	ResultSet resultSet1=null;
	ResultSet resultSet2=null;

	@Override
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID,String employeePass) {
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT employee_name,role FROM employee_master WHERE employee_id=? AND password=?");
			preparedStatement.setInt(1, employeeID);
			preparedStatement.setString(2, employeePass);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean=new FeedackManagementBean();
				String empName=resultSet.getString(1);
				String role=resultSet.getString(2);
				bean.setEmployeeName(empName);
				bean.setRole(role);
				list.add(bean);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return list;
	}
	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails() {
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT faculty_id,skill_set FROM faculty_skill");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int facultyId=resultSet.getInt(1);
				String skillSet=resultSet.getString(2);
				bean1.setFacultyId(facultyId);
				bean1.setSkillSet(skillSet);
				skillList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return skillList;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails(int courseId) {
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT course_name FROM course_master WHERE course_id=?");
			preparedStatement.setInt(1, courseId);
			resultSet=preparedStatement.executeQuery();
			String courseName=null;
			while(resultSet.next()){
				courseName=resultSet.getString(1);
				preparedStatement1=connection.prepareStatement("SELECT * FROM faculty_skill WHERE skill_set LIKE ? "
						+ "OR skill_set LIKE ? OR skill_set LIKE ?");
				preparedStatement1.setString(1,"%"+courseName+"%");
				preparedStatement1.setString(2,courseName+"%");
				preparedStatement1.setString(3,"%"+courseName);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					FeedackManagementBean bean1=new FeedackManagementBean();
					int facultyId=resultSet1.getInt(1);
					String skillSet=resultSet1.getString(2);
					bean1.setFacultyId(facultyId);
					bean1.setSkillSet(skillSet);
					skillList.add(bean1);
				}
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return skillList;
	}

	@Override
	public boolean updateFacultyDetails(int employeeId,String skills) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM employee_master WHERE employee_id=? AND role='Faculty'");
			preparedStatement.setInt(1, employeeId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				preparedStatement1=connection.prepareStatement("UPDATE faculty_skill SET skill_set=? WHERE faculty_id=?");
				preparedStatement1.setString(1, skills);
				preparedStatement1.setInt(2, employeeId);
				int n=preparedStatement1.executeUpdate();
				if(n==1){
					value=true;
				}
				else{
					value=false;
				}
			}
			else{
				System.err.println("No faculty is available with this ID");
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public boolean deleteFaculty(int deleteFacultyID) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("DELETE FROM faculty_skill WHERE faculty_id=?");
			preparedStatement.setInt(1, deleteFacultyID);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public boolean addCourse(String courseName, int duration) throws CourseException{
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("INSERT INTO course_master VALUES(course_id_sequence.nextval,?,?)");
			preparedStatement.setString(1, courseName);
			preparedStatement.setInt(2, duration);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(SQLException exception){
			throw new CourseException("This course already exixts and cannot be added anymore");
		}
		return value;
	}

	@Override
	public boolean deleteCourse(int courseID) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("DELETE FROM course_master WHERE course_id=?");
			preparedStatement.setInt(1, courseID);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveCourseDetails() {
		ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT course_id,course_name,no_of_days FROM course_master");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int courseId=resultSet.getInt(1);
				String courseName=resultSet.getString(2);
				int noOfDays=resultSet.getInt(3);
				bean1.setCourseId(courseId);
				bean1.setCourseName(courseName);
				bean1.setNoOfDays(noOfDays);
				courseList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return courseList;
	}
	@Override
	public boolean addFeedbackDetails(int employeeID,int presComm, int clrDbts, int tm,int hndout, int hsn,String comments,String sugg) {
		connection=DBUtil.conn();
		try{
			preparedStatement1=connection.prepareStatement("SELECT training_code FROM training_partici_enroll WHERE participant_id=?");
			preparedStatement1.setInt(1, employeeID);
			resultSet1=preparedStatement1.executeQuery();
			while(resultSet1.next()){
				int trCode=resultSet1.getInt(1);

				preparedStatement=connection.prepareStatement("INSERT INTO feedback_master values(?,?,?,?,?,?,?,?,?)");
				preparedStatement.setInt(1, trCode);
				preparedStatement.setInt(2,employeeID);
				preparedStatement.setInt(3, presComm);
				preparedStatement.setInt(4, clrDbts);
				preparedStatement.setInt(5, tm);
				preparedStatement.setInt(6, hndout);
				preparedStatement.setInt(7, hsn);
				preparedStatement.setString(8, comments);
				preparedStatement.setString(9, sugg);
				int n=preparedStatement.executeUpdate();

				if(n==1){
					value=true;
				}
				else{
					value=false;
				}
			}

		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public ArrayList<FeedackManagementBean> viewAllFeedbackDetails() {
		ArrayList<FeedackManagementBean> feedbackList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT training_code,FB_Prs_comm,FB_Clrfy_dbts,FB_TM,FB_Hnd_out,FB_Hw_Sw_Ntwrk FROM feedback_master");
			resultSet=preparedStatement.executeQuery();
			String employeeName=null;
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int trainingCode=resultSet.getInt(1);
				preparedStatement1=connection.prepareStatement("SELECT faculty_code FROM training_program WHERE training_code=?");
				preparedStatement1.setInt(1, trainingCode);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					int facultyCode=resultSet1.getInt(1);
					preparedStatement2=connection.prepareStatement("SELECT employee_name FROM employee_master WHERE employee_id=?");
					preparedStatement2.setInt(1, facultyCode);
					resultSet2=preparedStatement2.executeQuery();
					while(resultSet2.next()){
						employeeName=resultSet2.getString(1);
					}
				}
				bean1.setEmployeeName(employeeName);
				bean1.setTrainingCode(trainingCode);
				bean1.setFbPresComm(resultSet.getInt(2));
				bean1.setFbClrfyDbts(resultSet.getInt(3));
				bean1.setFbTM(resultSet.getInt(4));
				bean1.setFbHndOut(resultSet.getInt(5));
				bean1.setFbHwSwNtwrk(resultSet.getInt(6));
				feedbackList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return feedbackList;
	}
	@Override
	public boolean addTrainingProgram(int courseId, int facultyId,String startDate, String endDate) {
		connection=DBUtil.conn();
		try{
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date = sdf1.parse(startDate);
			java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf2.parse(endDate);
			java.sql.Date sqlStartDate1 = new java.sql.Date(date1.getTime());

			preparedStatement=connection.prepareStatement("INSERT INTO training_program VALUES(training_code_sequence.nextval,?,?,?,?)");
			preparedStatement.setInt(1, courseId);
			preparedStatement.setInt(2, facultyId);
			preparedStatement.setDate(3, sqlStartDate);
			preparedStatement.setDate(4, sqlStartDate1);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean retrieveCourseId(int courseId) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM training_program WHERE course_code=?");
			preparedStatement.setInt(1, courseId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public ArrayList<FeedackManagementBean> retrieveTrainingProgramDetails() {
		ArrayList<FeedackManagementBean> trainingList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT * FROM training_program");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				bean1.setTrainingCode(resultSet.getInt(1));
				bean1.setCourseId(resultSet.getInt(2));
				bean1.setFacultyId(resultSet.getInt(3));
				bean1.setStartDate(resultSet.getString(4));
				bean1.setEndDate(resultSet.getString(5));
				trainingList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return trainingList;
	}
	@Override
	public boolean validateTrainingCode(int trainingCode){
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM training_program WHERE training_code=?");
			preparedStatement.setInt(1, trainingCode);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(SQLException exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public boolean validateCourseId(int courseCode) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM course_master WHERE course_id=?");
			preparedStatement.setInt(1, courseCode);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public boolean validateTrainingProgramCourseCode(int courseCodeUpdate,int trainingCode) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT course_name FROM course_master WHERE course_id=?");
			preparedStatement.setInt(1, courseCodeUpdate);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				String courseName=resultSet.getString(1);
				preparedStatement1=connection.prepareStatement("SELECT faculty_code FROM training_program WHERE training_code=?");
				preparedStatement1.setInt(1, trainingCode);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					int facultyCode=resultSet1.getInt(1);
					preparedStatement2=connection.prepareStatement("SELECT count(*) FROM faculty_skill WHERE faculty_id=? AND (skill_set LIKE ? "
							+ "OR skill_set LIKE ? OR skill_set LIKE ?)");
					preparedStatement2.setInt(1, facultyCode);
					preparedStatement2.setString(2,"%"+courseName+"%");
					preparedStatement2.setString(3,courseName+"%");
					preparedStatement2.setString(4,"%"+courseName);
					resultSet2=preparedStatement2.executeQuery();
					int count=0;
					while(resultSet2.next()){
						count=Integer.parseInt(resultSet2.getString(1));
					}
					if(count==1){
						value=true;
					}
					else{
						value=false;
					}
				}
			}
		}
		catch(SQLException exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean updateTrainingProgramCourseCode(int courseCodeUpdate,int trainingCode) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("UPDATE training_program SET course_code=? WHERE training_code=?");
			preparedStatement.setInt(1, courseCodeUpdate);
			preparedStatement.setInt(2, trainingCode);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean deleteTrainingProgram(int trainingCode) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("DELETE FROM training_program WHERE training_code=?");
			preparedStatement.setInt(1, trainingCode);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public ArrayList<FeedackManagementBean> getFacultyDetails(int courseCode) {
		ArrayList<FeedackManagementBean> facultySkillList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT faculty_code FROM training_program WHERE course_code=?");
			preparedStatement.setInt(1, courseCode);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				int facultyCode=resultSet.getInt(1);
				preparedStatement1=connection.prepareStatement("SELECT * FROM faculty_skill WHERE faculty_id=?");
				preparedStatement1.setInt(1, facultyCode);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					FeedackManagementBean bean1=new FeedackManagementBean();
					bean1.setFacultyId(resultSet1.getInt(1));
					bean1.setSkillSet(resultSet1.getString(2));
					facultySkillList.add(bean1);
				}
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return facultySkillList;
	}
	@Override
	public boolean addStartAndEndDate(String startDate,String endDate,int trainingCode) {
		connection=DBUtil.conn();
		try{
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date = sdf1.parse(startDate);
			java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf2.parse(endDate);
			java.sql.Date sqlStartDate1 = new java.sql.Date(date1.getTime());

			preparedStatement=connection.prepareStatement("UPDATE training_program SET start_date=?,end_date=? WHERE training_code=?");
			preparedStatement.setDate(1, sqlStartDate);
			preparedStatement.setDate(2, sqlStartDate1);
			preparedStatement.setInt(3, trainingCode);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean validateParticipantId(int id) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM employee_master WHERE employee_id=? AND role='User'");
			preparedStatement.setInt(1, id);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean addTrainingParticipant(int trainingCode,int participantId) throws CourseException {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("INSERT INTO training_partici_enroll VALUES(?,?)");
			preparedStatement.setInt(1, trainingCode);
			preparedStatement.setInt(2, participantId);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			throw new CourseException("This is invalid training program and cannot be added!!!");
		}
		return value;
	}
	@Override
	public boolean validateParticipantWithTrainingCode(int trainingCode,
			int participantId) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT * FROM training_partici_enroll WHERE training_code=? AND participant_id=?");
			preparedStatement.setInt(1, trainingCode);
			preparedStatement.setInt(2, participantId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public ArrayList<FeedackManagementBean> retrieveTrainingParticipantEnrollDetails(int participantId) {
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT training_code FROM training_partici_enroll WHERE participant_id=?");
			preparedStatement.setInt(1, participantId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean=new FeedackManagementBean();
				bean.setTrainingCode(resultSet.getInt(1));
				list.add(bean);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return list;
	}
	@Override
	public boolean validateUser(int participantId) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM feedback_master WHERE participant_id=?");
			preparedStatement.setInt(1, participantId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public ArrayList<FeedackManagementBean> getFacultyDetails() {
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT faculty_code FROM training_program");
			resultSet=preparedStatement.executeQuery();
			int facultyCode;
			String facultyName=null;
			while(resultSet.next()){
				FeedackManagementBean bean=new FeedackManagementBean();
				facultyCode=resultSet.getInt(1);
				preparedStatement1=connection.prepareStatement("SELECT employee_name FROM employee_master WHERE employee_id=?");
				preparedStatement1.setInt(1, facultyCode);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					facultyName=resultSet1.getString(1);
				}
				bean.setFacultyId(facultyCode);
				bean.setEmployeeName(facultyName);
				list.add(bean);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return list;
	}
	@Override
	public boolean validateFaculty(int facultyId) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT training_code FROM training_program WHERE faculty_code=?");
			preparedStatement.setInt(1, facultyId);
			resultSet=preparedStatement.executeQuery();
			int trainingCode=0;
			while(resultSet.next()){
				trainingCode=resultSet.getInt(1);
				preparedStatement1=connection.prepareStatement("SELECT count(*) FROM feedback_master WHERE training_code=?");
				preparedStatement1.setInt(1, trainingCode);
				resultSet1=preparedStatement1.executeQuery();
				int count=0;
				while(resultSet1.next()){
					count=Integer.parseInt(resultSet1.getString(1));
				}
				if(count>0){
					value=true;
				}
				else{
					value=false;
				}
			}
		}
		
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public ArrayList<FeedackManagementBean> facultyWiseFeedback(int facultyId) {
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT training_code FROM training_program WHERE faculty_code=?");
			preparedStatement.setInt(1, facultyId);
			resultSet=preparedStatement.executeQuery();
			int trainingCode;
			int f1=0;
			int f2=0;
			int f3=0;
			int f4=0;
			int f5=0;
			while(resultSet.next()){
				FeedackManagementBean bean=new FeedackManagementBean();
				trainingCode=resultSet.getInt(1);
				preparedStatement1=connection.prepareStatement("SELECT training_code,FB_Prs_comm,FB_Clrfy_dbts,FB_TM,FB_Hnd_out,FB_Hw_Sw_Ntwrk FROM feedback_master WHERE training_code=?");
				preparedStatement1.setInt(1, trainingCode);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					f1=resultSet1.getInt(2);
					f2=resultSet1.getInt(3);
					f3=resultSet1.getInt(4);
					f4=resultSet1.getInt(5);
					f5=resultSet1.getInt(6);
				}
				bean.setTrainingCode(trainingCode);
				bean.setFbPresComm(f1);
				bean.setFbClrfyDbts(f2);
				bean.setFbTM(f3);
				bean.setFbHndOut(f4);
				bean.setFbHwSwNtwrk(f5);
				list.add(bean);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return list;
	}
	@Override
	public boolean validateFaculty1(int employeeId) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM faculty_skill WHERE faculty_id=?");
			preparedStatement.setInt(1, employeeId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean validateFacultyId(int facultyId) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM faculty_skill WHERE faculty_id=?");
			preparedStatement.setInt(1, facultyId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
}
