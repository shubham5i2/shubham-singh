package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.exception.CourseException;
import com.cg.fms.util.DBUtil;

public class FeedbackManagementDao implements IFeedbackManagementDao{

	boolean value=false;
	static Connection connection=null;
	PreparedStatement preparedStatement=null;
	PreparedStatement preparedStatement1=null;
	ResultSet resultSet=null;
	ResultSet resultSet1=null;

	@Override
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID,String employeePass) {
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT employee_name,role FROM employee_master WHERE employee_id=? AND password=?");
			preparedStatement.setInt(1, employeeID);
			preparedStatement.setString(2, employeePass);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean=new FeedackManagementBean();
				String empName=resultSet.getString(1);
				String role=resultSet.getString(2);
				bean.setEmployeeName(empName);
				bean.setRole(role);
				list.add(bean);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return list;
	}
	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails() {
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT faculty_id,skill_set FROM faculty_skill");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int facultyId=resultSet.getInt(1);
				String skillSet=resultSet.getString(2);
				bean1.setFacultyId(facultyId);
				bean1.setSkillSet(skillSet);
				skillList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return skillList;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails(int courseId) {
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT course_name FROM course_master WHERE course_id=?");
			preparedStatement.setInt(1, courseId);
			resultSet=preparedStatement.executeQuery();
			String courseName=null;
			while(resultSet.next()){
				courseName=resultSet.getString(1);
				preparedStatement1=connection.prepareStatement("SELECT * FROM faculty_skill WHERE skill_set LIKE ? "
						+ "OR skill_set LIKE ? OR skill_set LIKE ?");
				preparedStatement1.setString(1,"%"+courseName+"%");
				preparedStatement1.setString(2,courseName+"%");
				preparedStatement1.setString(3,"%"+courseName);
				resultSet1=preparedStatement1.executeQuery();
				while(resultSet1.next()){
					FeedackManagementBean bean1=new FeedackManagementBean();
					int facultyId=resultSet1.getInt(1);
					String skillSet=resultSet1.getString(2);
					bean1.setFacultyId(facultyId);
					bean1.setSkillSet(skillSet);
					skillList.add(bean1);
				}
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return skillList;
	}

	@Override
	public boolean updateFacultyDetails(int employeeId,String skills) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT count(*) FROM employee_master WHERE employee_id=? AND role='Faculty'");
			preparedStatement.setInt(1, employeeId);
			resultSet=preparedStatement.executeQuery();
			int count=0;
			while(resultSet.next()){
				count=Integer.parseInt(resultSet.getString(1));
			}
			if(count>0){
				preparedStatement1=connection.prepareStatement("UPDATE faculty_skill SET skill_set=? WHERE faculty_id=?");
				preparedStatement1.setString(1, skills);
				preparedStatement1.setInt(2, employeeId);
				int n=preparedStatement1.executeUpdate();
				if(n==1){
					value=true;
				}
				else{
					value=false;
				}
			}
			else{
				System.err.println("No faculty is available with this ID");
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public boolean deleteFaculty(int deleteFacultyID) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("DELETE FROM faculty_skill WHERE faculty_id=?");
			preparedStatement.setInt(1, deleteFacultyID);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public boolean addCourse(String courseName, int duration) throws CourseException{
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("INSERT INTO course_master VALUES(course_id_sequence.nextval,?,?)");
			preparedStatement.setString(1, courseName);
			preparedStatement.setInt(2, duration);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(SQLException exception){
			throw new CourseException("This course already exixts");
		}
		return value;
	}

	@Override
	public boolean deleteCourse(int courseID) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("DELETE FROM course_master WHERE course_id=?");
			preparedStatement.setInt(1, courseID);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveCourseDetails() {
		ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT course_id,course_name,no_of_days FROM course_master");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int courseId=resultSet.getInt(1);
				String courseName=resultSet.getString(2);
				int noOfDays=resultSet.getInt(3);
				bean1.setCourseId(courseId);
				bean1.setCourseName(courseName);
				bean1.setNoOfDays(noOfDays);
				courseList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return courseList;
	}
	@Override
	public boolean addFeedbackDetails(int employeeID,int presComm, int clrDbts, int tm,int hndout, int hsn,String comments,String sugg) {
		connection=DBUtil.conn();
		try{
			preparedStatement1=connection.prepareStatement("SELECT training_code FROM training_partici_enroll WHERE participant_id=?");
			preparedStatement1.setInt(1, employeeID);
			resultSet1=preparedStatement1.executeQuery();
			while(resultSet1.next()){
				int trCode=resultSet1.getInt(1);

				preparedStatement=connection.prepareStatement("INSERT INTO feedback_master values(?,?,?,?,?,?,?,?,?)");
				preparedStatement.setInt(1, trCode);
				preparedStatement.setInt(2,employeeID);
				preparedStatement.setInt(3, presComm);
				preparedStatement.setInt(4, clrDbts);
				preparedStatement.setInt(5, tm);
				preparedStatement.setInt(6, hndout);
				preparedStatement.setInt(7, hsn);
				preparedStatement.setString(8, comments);
				preparedStatement.setString(9, sugg);
				int n=preparedStatement.executeUpdate();

				if(n==1){
					value=true;
				}
				else{
					value=false;
				}
			}

		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean viewFeedbackDetails() {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("SELECT * FROM feedback_master");
			resultSet=preparedStatement.executeQuery();
			if(resultSet!=null){
				value=true;
			}
			else{
				value=false;
			}
		}

		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean addTrainingProgram(int courseId, int facultyId,String startDate, String endDate) {
		connection=DBUtil.conn();
		try{
			preparedStatement=connection.prepareStatement("INSERT INTO training_program VALUES(training_code_sequence.nextval,?,?,?,?)");
			preparedStatement.setInt(1, courseId);
			preparedStatement.setInt(2, facultyId);
			preparedStatement.setDate(3, startDate);
			preparedStatement.setDate(4, endDate);
			int n=preparedStatement.executeUpdate();
			if(n==1){
				value=true;
			}
			else{
				value=false;
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
}
