package com.cg.fms.dao;

import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.exception.CourseException;

public interface IFeedbackManagementDao {
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID,String employeePass);
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails();
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails(int courseId);
	public boolean updateFacultyDetails(int employeeId,String skills);
	public boolean deleteFaculty(int deleteFacultyID);
	public boolean addCourse(String courseName,int duration) throws CourseException;
	public boolean deleteCourse(int courseID);
	public ArrayList<FeedackManagementBean> retrieveCourseDetails();
	public boolean addTrainingProgram(int courseId,int facultyId,String startDate,String endDate);
	public boolean addFeedbackDetails(int employeeID,int presComm,int clrDbts,int tm,int hndout,int hsn,String comments,String sugg);
	public boolean viewFeedbackDetails();
}
