package com.cg.fms.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.exception.CourseException;
import com.cg.fms.service.FeedbackManagementService;
import com.cg.fms.service.IFeedbackManagementService;

public class FeedbackClient {
	public static void main(String[] args) throws CourseException {
		int num=1;
		int roleChoice=0;
		boolean result=false;
		boolean result1=false;
		boolean result2=false;
		boolean result3=false;
		boolean result4=false;
		boolean result5=false;
		boolean result6=false;
		boolean result7=false;
		boolean result8=false;
		boolean result9=false;
		boolean result10=false;
		boolean result11=false;
		boolean result12=false;
		boolean result13=false;
		boolean result14=false;
		IFeedbackManagementService service=new FeedbackManagementService();
		System.out.println("***************************************");
		System.out.println("Welcome to Feedback Management System");
		System.out.println("***************************************");
		do{
			System.out.println("======================================");
			System.out.println("1.Admin 2.Cordinator 3.User 4.Exit");
			System.out.println("======================================");
			Scanner choiceScanner=new Scanner(System.in);
			try{
				roleChoice=choiceScanner.nextInt();
			}
			catch(Exception e){
				System.err.println("Please enter a valid option");
			}
			switch (roleChoice) {
			case 1:
				System.out.println("Please enter your employee ID:");
				Scanner scannerID=new Scanner(System.in);
				int employeeID=scannerID.nextInt();
				System.out.println("Enter your password: ");
				Scanner scannerPass=new Scanner(System.in);
				String employeePass=scannerPass.next();
				ArrayList<FeedackManagementBean> arrayList=new ArrayList<FeedackManagementBean>();
				arrayList=service.retrieveDetails(employeeID,employeePass);
				if(arrayList.isEmpty()){
					System.err.println("\nInvalid credentials\n");
				}
				else{
					for (FeedackManagementBean feedackManagementBean : arrayList) {

						System.out.println("Welcome "+feedackManagementBean.getEmployeeName()+"\nRole is: "+feedackManagementBean.getRole());
						while(true){
							int choice=0;
							System.out.println("=================================================================================");
							System.out.println("1.Faculty Skill Maintainence 2.Course Maintainence 3.View Feedback Report 4.Exit");
							System.out.println("=================================================================================");
							System.out.println("Enter any choice from above");
							Scanner scannerAdminChoice=new Scanner(System.in);
							try{
								choice=scannerAdminChoice.nextInt();
							}
							catch(Exception e){
								System.err.println("Please enter a valid option");
							}
							if(choice==4){
								break;
							}

							switch (choice) {
							case 1:
								do{
									ArrayList<FeedackManagementBean> facultyList=new ArrayList<FeedackManagementBean>();
									IFeedbackManagementService service1=new FeedbackManagementService();
									System.out.println("=========================================================================");
									System.out.println("1.Update faculty details 2.Delete faculty 3.View faculty details 4.Exit");
									System.out.println("=========================================================================");
									System.out.println("Enter any choice from above");
									Scanner scanner=new Scanner(System.in);
									int adminChoice=scanner.nextInt();
									if(adminChoice==1){
										while(true){
											System.out.println("============================================");
											System.out.println("List of faculties that can be updated are");
											System.out.println("============================================");
											facultyList=service1.retrieveFacultyDetails();
											if(facultyList.isEmpty()){
												System.err.println("No faculty/ies is/sre available");
												break;
											}
											else{
												for (FeedackManagementBean feedackManagementBean2 : facultyList) {
													System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()
															+"\nSkill Set: "+feedackManagementBean2.getSkillSet());
													System.out.println("----------------------------------------------");
												}
												break;
											}
										}
										while(true){
											System.out.println("Enter employee ID to update: ");
											Scanner scannerEmpId=new Scanner(System.in);
											int employeeId=scannerEmpId.nextInt();
											boolean result15=service1.validateFaculty1(employeeId);
											if(result15==true){
												System.out.println("Enter skills:");
												Scanner scannerSkill=new Scanner(System.in);
												String skills=scannerSkill.nextLine();
												result2=service1.updateFacultyDetails(employeeId,skills);
												if(result2==true){
													System.out.println("Faculty details updated successfully\n");
												}
												break;
											}
											else{
												System.err.println("No faculty is available with this ID. Hence cannot be updated");
												break;
											}
										}
									}
									else if(adminChoice==2){
										while(true){
											System.out.println("============================================");
											System.out.println("List of faculties that can be deleted are");
											System.out.println("============================================");
											facultyList=service1.retrieveFacultyDetails();
											if(facultyList.isEmpty()){
												System.err.println("No faculty/ies is/sre available");
												break;
											}
											else{
												for (FeedackManagementBean feedackManagementBean2 : facultyList) {
													System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()
															+"\nSkill Set: "+feedackManagementBean2.getSkillSet());
													System.out.println("----------------------------------------------");
												}
												break;
											}
										}
										while(true){
											System.out.println("Enter the faculty ID to delete: ");
											Scanner scannerDeleteFaculty=new Scanner(System.in);
											int deleteFacultyID=scannerDeleteFaculty.nextInt();
											result3=service1.deleteFaculty(deleteFacultyID);
											if(result3==true){
												System.out.println("Faculty with ID: "+deleteFacultyID+" deleted successfully");
											}
											else{
												System.err.println("Faculty with this ID is not available. Hence cannot be updated");
											}
										}
									}
									else if(adminChoice==3){
										ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
										skillList=service1.retrieveFacultyDetails();
										if(skillList.isEmpty()){
											System.err.println("No faculty list is available to display");
										}
										else{
											System.out.println("======================");
											System.out.println("Faculty Details are:");
											System.out.println("======================");
											for (FeedackManagementBean feedackManagementBean2 : skillList) {
												System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()+"\nSkill Set: "+feedackManagementBean2.getSkillSet());
												System.out.println();
											}
										}
									}
									else{
										System.out.println("Thank you!!!");
										break;
									}

								}while(choice!=4);
								break;
							case 2:
								int option;
								do{
									ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
									IFeedbackManagementService service2=new FeedbackManagementService();
									System.out.println("========================================================");
									System.out.println("1.Add new course 2.Delete course 3.View courses 4.Exit");
									System.out.println("========================================================");
									Scanner scannerCourse=new Scanner(System.in);
									option=scannerCourse.nextInt();
									if(option==1){
										System.out.println("Enter course name: ");
										Scanner scannerCourseName=new Scanner(System.in);
										String courseName=scannerCourseName.nextLine();
										System.out.println("Enter the duration of the course: ");
										Scanner scannerDuration=new Scanner(System.in);
										int duration=scannerDuration.nextInt();
										try
										{
											result4=service2.addCourse(courseName, duration);
										}
										catch(CourseException e)
										{
											System.err.println(e);
										}
										if(result4==true){
											System.out.println("Course added successfully\n");
										}
									}
									else if(option==2){
										courseList=service.retrieveCourseDetails();
										if(courseList.isEmpty()){
											System.err.println("No course is available to delete");
										}
										else{
											System.out.println("========================================");
											System.out.println("List of courses that can be deleted are");
											System.out.println("========================================");
											for (FeedackManagementBean feedackManagementBean2 : courseList) {
												System.out
												.println("Course ID: "+feedackManagementBean2.getCourseId()
														+"\nCourse Name: "+feedackManagementBean2.getCourseName()
														+"\nDuration: "+feedackManagementBean2.getNoOfDays());
												System.out
												.println("----------------------------------");
											}
											System.out.println("Enter the course ID to delete: ");
											Scanner scannerDeleteCourse=new Scanner(System.in);
											int courseId=scannerDeleteCourse.nextInt();
											result5=service2.deleteCourse(courseId);
											if(result5==true){
												System.out.println("Course with ID: "+courseId+" deleted successfully");
											}
											else{
												System.err.println("No course with ID: "+courseId+" is available to delete!!!");
											}
										}
									}
									else if(option==3){
										courseList=service2.retrieveCourseDetails();
										System.out.println("===========================");
										System.out.println("List of Course Details are:");
										System.out.println("===========================");
										for (FeedackManagementBean feedackManagementBean2 : courseList) {
											System.out.println("Course ID: "+feedackManagementBean2.getCourseId()+"\nCourse Name: "
													+feedackManagementBean2.getCourseName()+"\nNo of Days: "+feedackManagementBean2.getNoOfDays());
											System.out.println("-----------------------------------");
										}
									}
									else{
										break;
									}
								}while(option!=4);
								break;
							case 3:
								IFeedbackManagementService service3=new FeedbackManagementService();
								ArrayList<FeedackManagementBean> feedbackList=new ArrayList<FeedackManagementBean>();
								ArrayList<FeedackManagementBean> facultyList=new ArrayList<FeedackManagementBean>();
								ArrayList<FeedackManagementBean> feedbackList1=new ArrayList<FeedackManagementBean>();
								System.out.println("1.View all training programs feedback 2.View faculty wise feedback");
								Scanner scannerChoice=new Scanner(System.in);
								int feedbackChoice=scannerChoice.nextInt();
								if(feedbackChoice==1){
									feedbackList=service3.viewAllFeedbackDetails();
									System.out.println("\nFeedback report for all training programs are");
									System.out.println("--------------------------------------------------");
									for (FeedackManagementBean feedackManagementBean2 : feedbackList) {
										System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()
												+"\nFaculty Name: "+feedackManagementBean2.getEmployeeName()
												+"\nPresentation and Communication: "+feedackManagementBean2.getFbPresComm()
												+"\nClarify doubts: "+feedackManagementBean2.getFbClrfyDbts()
												+"\nTime Management: "+feedackManagementBean2.getFbTM()
												+"\nHandout: "+feedackManagementBean2.getFbHndOut()
												+"\nHW/SW/Network: "+feedackManagementBean2.getFbHwSwNtwrk());
										System.out.println("---------------------------------------------");
									}
								}
								else if(feedbackChoice==2){
									int facultyId;
									System.out.println("List of faculties are:");
									facultyList=service3.getFacultyDetails();
									for (FeedackManagementBean feedackManagementBean2 : facultyList) {
										System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()
												+"\nFaculty Name: "+feedackManagementBean2.getEmployeeName());
										System.out.println("----------------------------------");
									}
									while(true){
										System.out.println("To which faculty ID you want to view feedback");
										Scanner scannerFacultyId=new Scanner(System.in);
										facultyId=scannerFacultyId.nextInt();
										boolean result15=service3.validateFaculty(facultyId);
										if(result15==true){
											break;
										}
										else{
											System.err.println("Please enter a valid faculty code (or) No feedback is given to this ID");
										}
									}
									feedbackList1=service3.facultyWiseFeedback(facultyId);
									System.out.println("\nFeedback report according wise are");
									System.out.println("--------------------------------------------------");
									for (FeedackManagementBean feedackManagementBean2 : feedbackList1) {
										System.out.println("Training Code: "+feedackManagementBean2.getTrainingCode()
												+"\nPresentation and Communication: "+feedackManagementBean2.getFbPresComm()
												+"\nClarify doubts: "+feedackManagementBean2.getFbClrfyDbts()
												+"\nTime Management: "+feedackManagementBean2.getFbTM()
												+"\nHandout: "+feedackManagementBean2.getFbHndOut()
												+"\nHW/SW/Network: "+feedackManagementBean2.getFbHwSwNtwrk());
										System.out.println("------------------------------------------");
									}
								}
								else{
									System.err.println("Please enter a valid choice");
								}
								break;
							case 4:
								System.exit(0);
								break;
							default:
								break;
							}
						}
					}
				}
				break;



			case 2:
				System.out.println("Please enter your employee ID:");
				Scanner scannerID1=new Scanner(System.in);
				int employeeID1=scannerID1.nextInt();
				System.out.println("Enter your password: ");
				Scanner scannerPass1=new Scanner(System.in);
				String employeePass1=scannerPass1.next();
				arrayList=service.retrieveDetails(employeeID1,employeePass1);
				if(arrayList.isEmpty()){
					System.err.println("Invalid credentials");
				}
				else{
					for (FeedackManagementBean feedackManagementBean : arrayList) {

						System.out.println("Welcome "+feedackManagementBean.getEmployeeName()+"\nRole is: "+feedackManagementBean.getRole());
						while(true){
							IFeedbackManagementService service4=new FeedbackManagementService();
							System.out.println("======================================================================================");
							System.out.println("1.Training Program Maintenance 2.Participant Enrollment 3.View Feedback Report 4.Exit");
							System.out.println("======================================================================================");
							Scanner scanner=new Scanner(System.in);
							int option=scanner.nextInt();

							if(option==4){
								break;
							}

							switch (option) {
							case 1:
								int cordinatorChoice;
								do{
									IFeedbackManagementService service1=new FeedbackManagementService();
									ArrayList<FeedackManagementBean> list=new ArrayList<>();
									ArrayList<FeedackManagementBean> list1=new ArrayList<>();
									System.out.println("===============================================================================================================");
									System.out.println("1.Add new training program 2.Update training program 3.Delete training program 4.View training programs 5.Exit");
									System.out.println("===============================================================================================================");
									Scanner scannerCo=new Scanner(System.in);
									cordinatorChoice=scannerCo.nextInt();
									if(cordinatorChoice==1){
										while(true){
											System.out.println("======================");
											System.out.println("Available courses are:");
											System.out.println("======================");
											list=service1.retrieveCourseDetails();
											for (FeedackManagementBean feedackManagementBean2 : list) {
												System.out.println("Course ID: "+feedackManagementBean2.getCourseId()+"\nCourse Name: "
														+feedackManagementBean2.getCourseName()+"\nNo of Days: "+feedackManagementBean2.getNoOfDays());
												System.out.println("-----------------------------------");
											}
											System.out.println("Enter course code(id) to add: ");
											Scanner scannerCourseId=new Scanner(System.in);
											int courseId=scannerCourseId.nextInt();
											boolean courseResult=service1.retrieveCourseId(courseId);
											if(courseResult==true){
												System.err.println("This training program already exists and cannot be added anymore!!!");
												break;
											}
											list1=service1.retrieveFacultyDetails(courseId);
											if(!list1.isEmpty()){
												System.out
												.println("==========================================");
												System.err.println("Faculty available for this course are:");
												System.out
												.println("==========================================");
												for (FeedackManagementBean feedackManagementBean2 : list1) {
													System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()+"\nSkill set: "
															+feedackManagementBean2.getSkillSet());
													System.out.println("-----------------------------------");
												}
											}
											else{
												System.err.println("No faculty is available for this course ID. Hence cannot be added\n");
												break;
											}
											System.out.println("Enter faculty code(id) to add: ");
											Scanner scannerFacultyId=new Scanner(System.in);
											int facultyId=scannerFacultyId.nextInt();
											boolean result15=service.validateFacultyId(facultyId);
											if(result15==true){
												System.out.println("Enter start date(dd-MM-yyyy): ");
												Scanner scannerStartDate=new Scanner(System.in);
												String startDate=scannerStartDate.nextLine(); 
												System.out.println("Enter end date(dd-MM-yyyy): ");
												Scanner scannerEndDate=new Scanner(System.in);
												String endDate=scannerEndDate.nextLine();

												result6=service1.addTrainingProgram(courseId,facultyId,startDate,endDate);
												if(result6==true){
													System.out.println("New training program added successfully!!!\n");
													break;
												}
											}
											else{
												System.err
												.println("You have entered a wrong faculty ID!!!\n");
											}
										}
									}
									else if(cordinatorChoice==2){
										int trainingCode;
										while(true){
											System.out.println("===================================================");
											System.err.println("List of training programs that can be updated are:");
											System.out.println("===================================================");
											list=service1.retrieveTrainingProgramDetails();
											for (FeedackManagementBean feedackManagementBean2 : list) {
												System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()+" Course code: "
														+feedackManagementBean2.getCourseId()+" Faculty code: "+feedackManagementBean2.getFacultyId()
														+" Start Date: "+feedackManagementBean2.getStartDate()+" End Date: "+feedackManagementBean2.getEndDate());
												System.out.println("-------------------------------------------------------------------------------");
											}
											while(true){
												System.out.println("Enter training code to update: ");
												Scanner scannerTrainingCode=new Scanner(System.in);
												trainingCode=scannerTrainingCode.nextInt();
												result7=service1.validateTrainingCode(trainingCode);
												if(result7==true){
													System.out.println("Enter what you want to update: ");
													break;
												}
												else{
													System.err.println("No training program is available with this code.\nPlease enter a valid training code...");
												}
											}
											System.out.println("1.Course code(ID) 2.Faculty code(ID) 3.Start date and End date 4.Back");
											Scanner scannerUpdate=new Scanner(System.in);
											int choice=scannerUpdate.nextInt();
											if(choice==4){
												break;
											}
											switch (choice) {
											case 1:
												while(true){
													System.err.println("Available course ID's and course names are:");
													list=service1.retrieveCourseDetails();
													for (FeedackManagementBean feedackManagementBean2 : list) {
														System.out.println("Course ID: "+feedackManagementBean2.getCourseId()+"\nCourse Name: "
																+feedackManagementBean2.getCourseName());
														System.out.println("--------------------------------------------------------------");
													}
													System.out.println("Enter which course code(ID) you want to add and update in training program: ");
													Scanner scannerCourseCode=new Scanner(System.in);
													int courseCodeUpdate=scannerCourseCode.nextInt();
													result8=service1.validateCourseId(courseCodeUpdate);
													if(result8==true){
														result9=service1.validateTrainingProgramCourseCode(courseCodeUpdate,trainingCode); 
														if(result9==true){
															result10=service1.updateTrainingProgramCourseCode(courseCodeUpdate,trainingCode);
															if(result10==true){
																System.out.println("Training program updated successfully");
															}
															else{
																System.err.println("Something went wrong");
															}
														}
														else{
															System.err.println("This faculty cannot take the course with ID:"+courseCodeUpdate+"\nThis faculty can only take these course/s...");
															list1=service1.getFacultyDetails(courseCodeUpdate);
															for (FeedackManagementBean feedackManagementBean2 : list1) {
																System.out.println("Faculty code: "+feedackManagementBean2.getFacultyId()+
																		"Faculty skill: "+feedackManagementBean2.getSkillSet());
															}
														}
														break;
													}
													else{
														System.err.println("Please enter a valid course ID to update training program\n");
													}
												}

												break;
											case 2:

												break;
											case 3:
												System.out.println("Enter new start date(dd-MM-yyyy): ");
												Scanner scannerStartDate=new Scanner(System.in);
												String startDate=scannerStartDate.nextLine(); 
												System.out.println("Enter new end date(dd-MM-yyyy): ");
												Scanner scannerEndDate=new Scanner(System.in);
												String endDate=scannerEndDate.nextLine();
												result12=service1.addStartAndEndDate(startDate,endDate,trainingCode);
												if(result12==true){
													System.out.println("Start date and end date updated successfully");
												}
												break;
											case 4:
												System.exit(0);
												break;
											default:
												System.err.println("Enter a valid option");
											}
										}
									}
									else if(cordinatorChoice==3){
										System.err.println("List of training programs that can be deleted are:");
										System.out.println("------------------------------------------------");
										list=service1.retrieveTrainingProgramDetails();
										for (FeedackManagementBean feedackManagementBean2 : list) {
											System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()+" Course code: "
													+feedackManagementBean2.getCourseId()+" Faculty code: "+feedackManagementBean2.getFacultyId()
													+" Start Date: "+feedackManagementBean2.getStartDate()+" End Date: "+feedackManagementBean2.getEndDate());
											System.out.println("-------------------------------------------------------------------------------");
										}
										while(true){
											System.out.println("Enter training code to delete:");
											Scanner scannerTrainingCode=new Scanner(System.in);
											int trainingCode=scannerTrainingCode.nextInt();
											result7=service1.validateTrainingCode(trainingCode);
											if(result7==true){
												result11=service1.deleteTrainingProgram(trainingCode);
												if(result11==true){
													System.out.println("Training program with ID: "+trainingCode+" deleted successfully");
												}
												break;
											}
											else{
												System.err.println("No training program is available with this code.\nPlease enter a valid training code...");
											}
										}
									}
									else if(cordinatorChoice==4){
										System.err.println("List of training programs are:");
										System.out.println("------------------------------------");
										list=service1.retrieveTrainingProgramDetails();
										for (FeedackManagementBean feedackManagementBean2 : list) {
											System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()+" Course code: "
													+feedackManagementBean2.getCourseId()+" Faculty code: "+feedackManagementBean2.getFacultyId()
													+" Start Date: "+feedackManagementBean2.getStartDate()+" End Date: "+feedackManagementBean2.getEndDate());
											System.out.println("-------------------------------------------------------------------------------");
										}
									}
									else{
										break;
									}
								}while(cordinatorChoice!=5);

								break;
							case 2:
								while(true){
									ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
									IFeedbackManagementService service1=new FeedbackManagementService();
									System.out.println("Enter participant ID to add:");
									Scanner scannerPId=new Scanner(System.in);
									int participantId=scannerPId.nextInt();
									result12=service1.validateParticipantId(participantId);
									if(result12==true){
										System.out.println("Enter training code: ");
										Scanner scannerTrainingcode=new Scanner(System.in);
										int trainingCode=scannerTrainingcode.nextInt();
										try{
											result13=service1.addTrainingParticipant(trainingCode,participantId);
										}
										catch(CourseException e){
											System.err.println(e);
											System.out.println("Available training programs are:");
											list=service1.retrieveTrainingProgramDetails();
											for (FeedackManagementBean feedackManagementBean2 : list) {
												System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()
														+"\tCourse code: "+feedackManagementBean2.getCourseId()
														+"\tFaculty code: "+feedackManagementBean2.getFacultyId());
												System.out.println("--------------------------------------------------------------------------");
											}
											break;
										}
										if(result13==true){
											System.out.println("Added successfully");
											break;
										}
									}
									else{
										System.err.println("No participant exist with this ID...");
									}
								}
								break;
							case 3:
								IFeedbackManagementService service3=new FeedbackManagementService();
								ArrayList<FeedackManagementBean> feedbackList=new ArrayList<FeedackManagementBean>();
								ArrayList<FeedackManagementBean> facultyList=new ArrayList<FeedackManagementBean>();
								ArrayList<FeedackManagementBean> feedbackList1=new ArrayList<FeedackManagementBean>();
								System.out.println("1.View all training programs feedback 2.View faculty wise feedback");
								Scanner scannerChoice=new Scanner(System.in);
								int feedbackChoice=scannerChoice.nextInt();
								if(feedbackChoice==1){
									feedbackList=service3.viewAllFeedbackDetails();
									System.out.println("\nFeedback report for all training programs are");
									System.out.println("--------------------------------------------------");
									for (FeedackManagementBean feedackManagementBean2 : feedbackList) {
										System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()
												+"\nFaculty Name: "+feedackManagementBean2.getEmployeeName()
												+"\nPresentation and Communication: "+feedackManagementBean2.getFbPresComm()
												+"\nClarify doubts: "+feedackManagementBean2.getFbClrfyDbts()
												+"\nTime Management: "+feedackManagementBean2.getFbTM()
												+"\nHandout: "+feedackManagementBean2.getFbHndOut()
												+"\nHW/SW/Network: "+feedackManagementBean2.getFbHwSwNtwrk());
										System.out.println("---------------------------------------------");
									}
								}
								else if(feedbackChoice==2){
									int facultyId;
									System.out.println("List of faculties are:");
									facultyList=service3.getFacultyDetails();
									for (FeedackManagementBean feedackManagementBean2 : facultyList) {
										System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()
												+"\nFaculty Name: "+feedackManagementBean2.getEmployeeName());
										System.out.println("----------------------------------");
									}
									while(true){
										System.out.println("To which faculty ID you want to view feedback");
										Scanner scannerFacultyId=new Scanner(System.in);
										facultyId=scannerFacultyId.nextInt();
										boolean result15=service3.validateFaculty(facultyId);
										if(result15==true){
											break;
										}
										else{
											System.err.println("Please enter a valid faculty code (or) No feedback is given to this ID");
										}
									}
									feedbackList1=service3.facultyWiseFeedback(facultyId);
									System.out.println("\nFeedback report according wise are");
									System.out.println("--------------------------------------------------");
									for (FeedackManagementBean feedackManagementBean2 : feedbackList1) {
										System.out.println("Training Code: "+feedackManagementBean2.getTrainingCode()
												+"\nPresentation and Communication: "+feedackManagementBean2.getFbPresComm()
												+"\nClarify doubts: "+feedackManagementBean2.getFbClrfyDbts()
												+"\nTime Management: "+feedackManagementBean2.getFbTM()
												+"\nHandout: "+feedackManagementBean2.getFbHndOut()
												+"\nHW/SW/Network: "+feedackManagementBean2.getFbHwSwNtwrk());
										System.out.println("------------------------------------------");
									}
								}
								else{
									System.err.println("Please enter a valid choice");
								}
								break;

							default:
								break;
							}
						}
					}
				}
				break;



			case 3:
				System.out.println("Please enter your employee ID:");
				Scanner scannerID2=new Scanner(System.in);
				int employeeID2=scannerID2.nextInt();
				System.out.println("Enter your password: ");
				Scanner scannerPass2=new Scanner(System.in);
				String employeePass2=scannerPass2.next();
				boolean result15=service.validateUser(employeeID2);
				if(result15==true){
					System.err.println("You have already given your feedback.\nThank you!!!");
				}
				else{
					ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
					arrayList=service.retrieveDetails(employeeID2,employeePass2);
					if(arrayList.isEmpty()){
						System.out.println("Invalid credentials");
					}
					else{
						System.out.println("1.Give Feedback 2.Exit");
						System.out.println("-----------------------------------------------------");
						Scanner scanner=new Scanner(System.in);
						int option=scanner.nextInt();
						switch (option) {
						case 1:
							while(true){
								System.out.println("Training code:");
								Scanner scanner0=new Scanner(System.in);
								int trainingCode=scanner0.nextInt();
								result14=service.validateParticipantWithTrainingCode(trainingCode, employeeID2);
								if(result14==false){
									System.err.println("You are not registered with this course.\nHence you cannot give feedback to this training program");
									System.out.println("You are registered with training program:");
									System.out.println("----------------------------------------------------");
									list=service.retrieveTrainingParticipantEnrollDetails(employeeID2);
									for (FeedackManagementBean feedackManagementBean : list) {
										System.out.println(feedackManagementBean.getTrainingCode());
									}
								}
								else{
									break;
								}
							}
							System.out.println("Rate between 1 to 5");
							System.out.println("--------------------------------------");
							System.out.println("Presentation & communication: ");
							Scanner scanner2=new Scanner(System.in);
							int presComm=scanner2.nextInt();
							System.out.println("Clarify Doubts: ");
							Scanner scanner3=new Scanner(System.in);
							int clrDbts=scanner3.nextInt();
							System.out.println("Time Management: ");
							Scanner scanner4=new Scanner(System.in);
							int tm=scanner4.nextInt();
							System.out.println("Handout: ");
							Scanner scanner5=new Scanner(System.in);
							int hndout=scanner5.nextInt();
							System.out.println("H/W S/W Networks usage: ");
							Scanner scanner6=new Scanner(System.in);
							int hsn=scanner6.nextInt();
							System.out.println("--------------------------------------");
							System.out.println("Comments: ");
							Scanner scanner7=new Scanner(System.in);
							String comments=scanner7.nextLine();
							System.out.println("Suggestions:");
							Scanner scanner8=new Scanner(System.in);
							String sugg=scanner8.nextLine();
							result=service.addFeedbackDetails(employeeID2,presComm,clrDbts,tm,hndout,hsn,comments,sugg);
							if(result==true){
								System.out.println("Thank you for your valuable feedback!!!");
							}
							break;

						case 2:
							System.exit(0);
							break;

						default:
							break;
						}
					}
				}
				break;

			case 4:
				System.err.println("Thank you!!!");
				System.exit(0);
				break;



			default:
				break;
			} //main switch close
		}while(roleChoice!=4);
	}//main method close
}
