/*package com.cg.fms.service;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

public class FeedbackManagementServiceTest {

	@Test
	public void testRetrieveDetails() {
		FeedbackManagementService service=new FeedbackManagementService();
		assertEquals("admin", service.retrieveDetails(employeeID, employeePass).get(1));  
	}

	@Test
	public void testRetrieveFacultyDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testRetrieveFacultyDetailsInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateFacultyDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteFaculty() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddCourse() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteCourse() {
		fail("Not yet implemented");
	}

	@Test
	public void testRetrieveCourseDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddFeedbackDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewAllFeedbackDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddTrainingProgram() {
		fail("Not yet implemented");
	}

	@Test
	public void testRetrieveCourseId() {
		fail("Not yet implemented");
	}

	@Test
	public void testRetrieveTrainingProgramDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateTrainingCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateTrainingProgramCourseCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateCourseId() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateTrainingProgramCourseCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteTrainingProgram() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetFacultyDetailsInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddStartAndEndDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateParticipantId() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddTrainingParticipant() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateParticipantWithTrainingCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testRetrieveTrainingParticipantEnrollDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetFacultyDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateFaculty() {
		fail("Not yet implemented");
	}

	@Test
	public void testFacultyWiseFeedback() {
		fail("Not yet implemented");
	}

	@Test
	public void testObject() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetClass() {
		fail("Not yet implemented");
	}

	@Test
	public void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testEquals() {
		fail("Not yet implemented");
	}

	@Test
	public void testClone() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	@Test
	public void testNotify() {
		fail("Not yet implemented");
	}

	@Test
	public void testNotifyAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testWaitLong() {
		fail("Not yet implemented");
	}

	@Test
	public void testWaitLongInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testWait() {
		fail("Not yet implemented");
	}

	@Test
	public void testFinalize() {
		fail("Not yet implemented");
	}

}
*/