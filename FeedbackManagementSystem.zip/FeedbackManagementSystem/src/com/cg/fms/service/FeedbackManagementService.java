package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.dao.FeedbackManagementDao;
import com.cg.fms.dao.IFeedbackManagementDao;
import com.cg.fms.exception.CourseException;

public class FeedbackManagementService implements IFeedbackManagementService{

	@Override
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID,String employeePass) {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> arrayList=new ArrayList<FeedackManagementBean>();
		arrayList=dao.retrieveDetails(employeeID,employeePass);
		return arrayList;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		skillList=dao.retrieveFacultyDetails();
		return skillList;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails(int courseId) {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		skillList=dao.retrieveFacultyDetails(courseId);
		return skillList;
	}

	@Override
	public boolean updateFacultyDetails(int employeeId,String skills) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.updateFacultyDetails(employeeId,skills);
		return result;
	}

	@Override
	public boolean deleteFaculty(int deleteFacultyID) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.deleteFaculty(deleteFacultyID);
		return result;
	}

	@Override
	public boolean addCourse(String courseName, int duration) throws CourseException {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.addCourse(courseName, duration);
		return result;
	}

	@Override
	public boolean deleteCourse(int courseID) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.deleteCourse(courseID);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveCourseDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
		courseList=dao.retrieveCourseDetails();
		return courseList;
	}

	@Override
	public boolean addFeedbackDetails(int employeeID,int presComm, int clrDbts, int tm,int hndout, int hsn,String comments,String sugg) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.addFeedbackDetails(employeeID,presComm, clrDbts, tm, hndout, hsn,comments,sugg);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> viewAllFeedbackDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> feedbackList=new ArrayList<FeedackManagementBean>();
		feedbackList=dao.viewAllFeedbackDetails();
		return feedbackList;
	}

	@Override
	public boolean addTrainingProgram(int courseId, int facultyId,String startDate, String endDate) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.addTrainingProgram(courseId, facultyId, startDate, endDate);
		return result;
	}

	@Override
	public boolean retrieveCourseId(int courseId) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.retrieveCourseId(courseId);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveTrainingProgramDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> trainingList=new ArrayList<FeedackManagementBean>();
		trainingList=dao.retrieveTrainingProgramDetails();
		return trainingList;
	}

	@Override
	public boolean validateTrainingCode(int trainingCode){
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateTrainingCode(trainingCode);
		return result;
	}

	@Override
	public boolean validateTrainingProgramCourseCode(int courseCodeUpdate,int trainingCode) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateTrainingProgramCourseCode(courseCodeUpdate,trainingCode);
		return result;
	}

	@Override
	public boolean validateCourseId(int courseCode) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateCourseId(courseCode);
		return result;
	}

	@Override
	public boolean updateTrainingProgramCourseCode(int courseCodeUpdate,int trainingCode) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.updateTrainingProgramCourseCode(courseCodeUpdate,trainingCode);
		return result;
	}

	@Override
	public boolean deleteTrainingProgram(int trainingCode) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.deleteTrainingProgram(trainingCode);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> getFacultyDetails(int courseCode) {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> facultySkillList=new ArrayList<FeedackManagementBean>();
		facultySkillList=dao.getFacultyDetails(courseCode);
		return facultySkillList;
	}

	@Override
	public boolean addStartAndEndDate(String startDate,String endDate,int trainingCode) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.addStartAndEndDate(startDate,endDate,trainingCode);
		return result;
	}

	@Override
	public boolean validateParticipantId(int id) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateParticipantId(id);
		return result;
	}

	@Override
	public boolean addTrainingParticipant(int trainingCode,int participantId) throws CourseException {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.addTrainingParticipant(trainingCode, participantId);
		return result;
	}

	@Override
	public boolean validateParticipantWithTrainingCode(int trainingCode,
			int participantId) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateParticipantWithTrainingCode(trainingCode, participantId);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveTrainingParticipantEnrollDetails(int participantId) {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		list=dao.retrieveTrainingParticipantEnrollDetails(participantId);
		return list;
	}

	@Override
	public boolean validateUser(int participantId) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateUser(participantId);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> getFacultyDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		list=dao.getFacultyDetails();
		return list;
	}

	@Override
	public boolean validateFaculty(int facultyId) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateFaculty(facultyId);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> facultyWiseFeedback(int facultyId) {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		list=dao.facultyWiseFeedback(facultyId);
		return list;
	}

	@Override
	public boolean validateFaculty1(int employeeId) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateFaculty1(employeeId);
		return result;
	}

	@Override
	public boolean validateFacultyId(int facultyId) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.validateFacultyId(facultyId);
		return result;
	}
}


