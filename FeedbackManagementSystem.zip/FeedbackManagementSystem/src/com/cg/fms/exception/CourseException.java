package com.cg.fms.exception;

public class CourseException extends Exception{
	String message;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CourseException(String message) {
		this.message=message;
	}
	public String toString()
	{
		return this.message;
	}
}
