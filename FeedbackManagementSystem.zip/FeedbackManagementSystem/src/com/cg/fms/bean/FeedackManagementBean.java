package com.cg.fms.bean;

import java.io.Serializable;

public class FeedackManagementBean implements Serializable{
	private int employeeID;
	private String employeeName;
	private String role;
	private int facultyId;
	private String skillSet;
	private int courseId;
	private String courseName;
	private int noOfDays;
	private int trainingCode;
	private String startDate;
	private String endDate;
	private int fbPresComm;
	private int fbClrfyDbts;
	private int fbTM;
	private int fbHndOut;
	private int fbHwSwNtwrk;
	
	public int getFbPresComm() {
		return fbPresComm;
	}

	public void setFbPresComm(int fbPresComm) {
		this.fbPresComm = fbPresComm;
	}

	public int getFbClrfyDbts() {
		return fbClrfyDbts;
	}

	public void setFbClrfyDbts(int fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}

	public int getFbTM() {
		return fbTM;
	}

	public void setFbTM(int fbTM) {
		this.fbTM = fbTM;
	}

	public int getFbHndOut() {
		return fbHndOut;
	}

	public void setFbHndOut(int fbHndOut) {
		this.fbHndOut = fbHndOut;
	}

	public int getFbHwSwNtwrk() {
		return fbHwSwNtwrk;
	}

	public void setFbHwSwNtwrk(int fbHwSwNtwrk) {
		this.fbHwSwNtwrk = fbHwSwNtwrk;
	}

	public int getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public FeedackManagementBean() {
		// TODO Auto-generated constructor stub
	}
}
