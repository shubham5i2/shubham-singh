package com.cg.fms.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.exception.CourseException;
import com.cg.fms.service.FeedbackManagementService;
import com.cg.fms.service.IFeedbackManagementService;

public class FeedbackClient {
	public static void main(String[] args) throws CourseException {
		int num=1;
		int roleChoice;
		boolean result=false;
		boolean result1=false;
		boolean result2=false;
		boolean result3=false;
		boolean result4=false;
		boolean result5=false;
		boolean result6=false;
		IFeedbackManagementService service=new FeedbackManagementService();
		System.out.println("Welcome to Feedback Management System");
		System.out.println("-------------------------------------------");
		do{
			System.out.println("1.Admin 2.Cordinator 3.User 4.Exit");
			Scanner choiceScanner=new Scanner(System.in);
			roleChoice=choiceScanner.nextInt();

			switch (roleChoice) {
			case 1:
				System.out.println("Please enter your employee ID:");
				Scanner scannerID=new Scanner(System.in);
				int employeeID=scannerID.nextInt();
				System.out.println("Enter your password: ");
				Scanner scannerPass=new Scanner(System.in);
				String employeePass=scannerPass.next();
				ArrayList<FeedackManagementBean> arrayList=new ArrayList<FeedackManagementBean>();
				arrayList=service.retrieveDetails(employeeID,employeePass);
				if(arrayList.isEmpty()){
					System.err.println("Invalid credentials\n");
				}
				else{
					for (FeedackManagementBean feedackManagementBean : arrayList) {

						System.out.println("Welcome "+feedackManagementBean.getEmployeeName()+"\nRole is: "+feedackManagementBean.getRole());
						while(true){
							System.out.println("1.Faculty Skill Maintainence 2.Course Maintainence 3.View Feedback Report 4.Exit");
							Scanner scannerAdminChoice=new Scanner(System.in);
							int choice=scannerAdminChoice.nextInt();

							if(choice==4){
								break;
							}

							switch (choice) {
							case 1:
								do{
									IFeedbackManagementService service1=new FeedbackManagementService();
									System.out.println("1.Update faculty details 2.Delete faculty 3.View faculty details 4.Exit");
									Scanner scanner=new Scanner(System.in);
									int adminChoice=scanner.nextInt();
									if(adminChoice==1){
										System.out.println("Enter employee ID to update: ");
										Scanner scannerEmpId=new Scanner(System.in);
										int employeeId=scannerEmpId.nextInt();
										System.out.println("Enter skills:");
										Scanner scannerSkill=new Scanner(System.in);
										String skills=scannerSkill.next();
										result2=service1.updateFacultyDetails(employeeId,skills);
										if(result2==true){
											System.out.println("Faculty details updated successfully\n");
										}
									}
									else if(adminChoice==2){
										System.out.println("Enter the faculty ID to delete: ");
										Scanner scannerDeleteFaculty=new Scanner(System.in);
										int deleteFacultyID=scannerDeleteFaculty.nextInt();
										result3=service1.deleteFaculty(deleteFacultyID);
										if(result3==true){
											System.out.println("Faculty with ID: "+deleteFacultyID+" deleted successfully");
										}
										else{
											System.out.println("Faculty with this ID is not available!!!");
										}
									}
									else if(adminChoice==3){
										ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
										skillList=service1.retrieveFacultyDetails();
										System.out.println("Faculty Details are:");
										System.out.println("-----------------------------------");
										for (FeedackManagementBean feedackManagementBean2 : skillList) {
											System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()+"\nSkill Set: "+feedackManagementBean2.getSkillSet());
											System.out.println();
										}
									}
									else{
										System.out.println("Thank you!!!");
										break;
									}

								}while(choice!=4);
								break;
							case 2:
								int option;
								do{
									IFeedbackManagementService service2=new FeedbackManagementService();
									System.out.println("1.Add new course 2.Delete course 3.View courses 4.Exit");
									Scanner scannerCourse=new Scanner(System.in);
									option=scannerCourse.nextInt();
									if(option==1){
										System.out.println("Enter course name: ");
										Scanner scannerCourseName=new Scanner(System.in);
										String courseName=scannerCourseName.nextLine();
										System.out.println("Enter the duration of the course: ");
										Scanner scannerDuration=new Scanner(System.in);
										int duration=scannerDuration.nextInt();
										try
										{
											result4=service2.addCourse(courseName, duration);
										}
										catch(CourseException e)
										{
											System.out.println(e);
										}
										if(result4==true){
											System.out.println("Course added successfully\n");
										}
									}
									else if(option==2){
										System.out.println("Enter the course ID to delete: ");
										Scanner scannerDeleteCourse=new Scanner(System.in);
										int courseId=scannerDeleteCourse.nextInt();
										result5=service2.deleteCourse(courseId);
										if(result5==true){
											System.out.println("Course with ID: "+courseId+" deleted successfully");
										}
										else{
											System.out.println("Error occured while deleting");
										}
									}
									else if(option==3){
										ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
										courseList=service2.retrieveCourseDetails();
										System.out.println("Course Details are:");
										for (FeedackManagementBean feedackManagementBean2 : courseList) {
											System.out.println("Course ID: "+feedackManagementBean2.getCourseId()+"\nCourse Name: "
													+feedackManagementBean2.getCourseName()+"\nNo of Days: "+feedackManagementBean2.getNoOfDays());
											System.out.println("-----------------------------------");
										}
									}
									else{
										break;
									}
								}while(option!=4);
								break;
							case 3:
								IFeedbackManagementService service3=new FeedbackManagementService();
								result1=service3.viewFeedbackDetails();
								break;
							case 4:
								System.exit(0);
								break;
							default:
								break;
							}
						}
					}
				}
				break;



			case 2:
				System.out.println("Please enter your employee ID:");
				Scanner scannerID1=new Scanner(System.in);
				int employeeID1=scannerID1.nextInt();
				System.out.println("Enter your password: ");
				Scanner scannerPass1=new Scanner(System.in);
				String employeePass1=scannerPass1.next();
				arrayList=service.retrieveDetails(employeeID1,employeePass1);
				if(arrayList.isEmpty()){
					System.err.println("Invalid credentials");
				}
				else{
					for (FeedackManagementBean feedackManagementBean : arrayList) {

						System.out.println("Welcome "+feedackManagementBean.getEmployeeName()+"\nRole is: "+feedackManagementBean.getRole());
						while(true){
							IFeedbackManagementService service4=new FeedbackManagementService();
							System.out.println("1.Training Program Maintenance 2.Participant Enrollment 3.View Feedback Report 4.Exit");
							Scanner scanner=new Scanner(System.in);
							int option=scanner.nextInt();

							if(option==4){
								break;
							}

							switch (option) {
							case 1:
								int cordinatorChoice;
								do{
									IFeedbackManagementService service1=new FeedbackManagementService();
									ArrayList<FeedackManagementBean> list=new ArrayList<>();
									ArrayList<FeedackManagementBean> list1=new ArrayList<>();
									System.out.println("1.Add new training program 2.Update training program 3.Delete training program 4.Exit");
									Scanner scannerCo=new Scanner(System.in);
									cordinatorChoice=scannerCo.nextInt();
									if(cordinatorChoice==1){
										System.err.println("Available courses are:");
										System.out.println("-----------------------------------");
										list=service1.retrieveCourseDetails();
										for (FeedackManagementBean feedackManagementBean2 : list) {
											System.out.println("Course ID: "+feedackManagementBean2.getCourseId()+"\nCourse Name: "
													+feedackManagementBean2.getCourseName()+"\nNo of Days: "+feedackManagementBean2.getNoOfDays());
											System.out.println("-----------------------------------");
										}
										System.out.println("Enter course code(id) to add: ");
										Scanner scannerCourseId=new Scanner(System.in);
										int courseId=scannerCourseId.nextInt();
										boolean courseResult=service1.retrieveCourseId(courseId);
										if(courseResult==true){
											System.err.println("This course already exists and cannot be added anymore!!!");
											break;
										}
										list1=service1.retrieveFacultyDetails(courseId);
										if(!list1.isEmpty()){
											System.err.println("Faculty available for this course are:");
											System.out.println("-----------------------------------");
											for (FeedackManagementBean feedackManagementBean2 : list1) {
												System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()+"\nSkill set: "
														+feedackManagementBean2.getSkillSet());
												System.out.println("-----------------------------------");
											}
										}
										else{
											System.err.println("No faculty is available for this course");
											break;
										}
										System.out.println("Enter faculty code(id) to add: ");
										Scanner scannerFacultyId=new Scanner(System.in);
										int facultyId=scannerFacultyId.nextInt();
										System.out.println("Enter start date(dd-MM-yyyy): ");
										Scanner scannerStartDate=new Scanner(System.in);
										String startDate=scannerStartDate.nextLine(); 
										System.out.println("Enter end date(dd-MM-yyyy): ");
										Scanner scannerEndDate=new Scanner(System.in);
										String endDate=scannerEndDate.nextLine();

										result6=service1.addTrainingProgram(courseId,facultyId,startDate,endDate);
										if(result6==true){
											System.out.println("New training program added successfully!!!");
										}
										else{
											System.err.println("Error while adding training");
										}
									}
									else if(cordinatorChoice==2){
										System.err.println("List of training programs that can be updated are:");
										System.out.println("------------------------------------------------");
										list=service1.retrieveTrainingProgramDetails();
										for (FeedackManagementBean feedackManagementBean2 : list) {
											System.out.println("Training code: "+feedackManagementBean2.getTrainingCode()+" Course code: "
										+feedackManagementBean2.getCourseId()+" Faculty code: "+feedackManagementBean2.getFacultyId()
										+" Start Date: "+feedackManagementBean2.getStartDate()+" End Date: "+feedackManagementBean2.getEndDate());
											System.out.println("-------------------------------------------------------------------------------");
										}
										System.out.println("Enter training code to update: ");//continue
									}
									else if(cordinatorChoice==3){

									}
									else{
										break;
									}
								}while(cordinatorChoice!=4);

								break;
							case 2:

								break;
							case 3:

								break;

							default:
								break;
							}
						}
					}
				}
				break;



			case 3:
				System.out.println("Please enter your employee ID:");
				Scanner scannerID2=new Scanner(System.in);
				int employeeID2=scannerID2.nextInt();
				System.out.println("Enter your password: ");
				Scanner scannerPass2=new Scanner(System.in);
				String employeePass2=scannerPass2.next();
				ArrayList<FeedackManagementBean> arrayLis2t=new ArrayList<FeedackManagementBean>();
				arrayList=service.retrieveDetails(employeeID2,employeePass2);
				if(arrayList.isEmpty()){
					System.out.println("Invalid credentials");
				}
				else{
					IFeedbackManagementService service3=new FeedbackManagementService();
					System.out.println("1.All Training programs report 2.Faculty wise report");
					System.out.println("-----------------------------------------------------");
					Scanner scanner=new Scanner(System.in);
					int option=scanner.nextInt();
					switch (option) {
					case 1:
						System.out.println("Rate between 1 to 5");
						System.out.println("Training code:\n Faculty ID: \nFeedback Scores");
						System.out.println("Presentation & communication");
						Scanner scanner2=new Scanner(System.in);
						int presComm=scanner2.nextInt();
						System.out.println("Clarify Doubts");
						Scanner scanner3=new Scanner(System.in);
						int clrDbts=scanner3.nextInt();
						System.out.println("Time Management");
						Scanner scanner4=new Scanner(System.in);
						int tm=scanner4.nextInt();
						System.out.println("Handout");
						Scanner scanner5=new Scanner(System.in);
						int hndout=scanner5.nextInt();
						System.out.println("H/W S/W Networks usage");
						Scanner scanner6=new Scanner(System.in);
						int hsn=scanner6.nextInt();
						System.out.println("nComments");
						Scanner scanner7=new Scanner(System.in);
						String comments=scanner7.next();
						System.out.println("Suggestions");
						Scanner scanner8=new Scanner(System.in);
						String sugg=scanner8.next();
						result=service3.addFeedbackDetails(employeeID2,presComm,clrDbts,tm,hndout,hsn,comments,sugg);
						if(result==true){
							System.out.println("Thank you!!!");
						}
						break;

					case 2:

						break;

					default:
						break;
					}
				}
				break;



			case 4:
				System.err.println("Thank you!!!");
				System.exit(0);
				break;



			default:
				break;
			} //main switch close
		}while(roleChoice!=4);
	}//main method close
}
