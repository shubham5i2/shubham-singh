package com.example2.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example2.model.ImageEntity;

@Repository
public interface ImageRepository extends  MongoRepository<ImageEntity, String>{

}
