package com.example2.service;

import java.io.IOException;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example2.Repository.ImageRepository;
import com.example2.model.ImageEntity;

@Service
public class ImageService 
{
	@Autowired
	ImageRepository imageRepository;
	
	public ImageEntity getPhoto(String id) {
        return imageRepository.findById(id).get();
    }
	
	public String addPhoto(String title, MultipartFile file) throws IOException { 
        ImageEntity photo = new ImageEntity(title);
        photo.setImage(new Binary(BsonBinarySubType.BINARY, file.getBytes())); 
        photo = imageRepository.insert(photo);
        return photo.getId();
	}

}
