package com.example2.controller;

import java.io.IOException;
import java.util.Base64;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example2.model.ImageEntity;
import com.example2.service.ImageService;


@Controller
public class ImageController
{
	ImageService imageService;
	
	@RequestMapping("/photos/{id}")
    public String getPhoto(@PathVariable String id, Model model) {
        ImageEntity photo = imageService.getPhoto(id);
        model.addAttribute("title", photo.getTitle());
        model.addAttribute("image", Base64.getEncoder().encodeToString(photo.getImage().getData()));
        return "photos";
    }

    @RequestMapping("/photos/upload")
    public String uploadPhoto(Model model) {
        model.addAttribute("message", "hello");
        return "uploadPhoto";
    }

    @RequestMapping("/photos/add")
    public String addPhoto(@RequestParam("title") String title, @RequestParam("image") MultipartFile image, Model model) throws IOException {
        String id = imageService.addPhoto(title, image);
        return "redirect:/photos/" + id;
    }
    
    @RequestMapping("/")
    public String home() {
    	System.out.println("In Home Page");
    	return "index";
    }
}
	
