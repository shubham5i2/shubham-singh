package com.example.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.entity.Customer;

public interface IMongoRepository extends MongoRepository<Customer, String>{
		
}
