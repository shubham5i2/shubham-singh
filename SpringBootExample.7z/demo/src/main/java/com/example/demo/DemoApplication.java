package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.example.repository.IMongoRepository;
import com.example.entity.Customer;

@EnableMongoRepositories("com.example")
@SpringBootApplication
public class DemoApplication implements CommandLineRunner{
	
	@Autowired
	private IMongoRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		repository.deleteAll(); //to delete customer if any
		
		//Insert customer details
		repository.save(new Customer("Shubham","Kumar"));
		repository.save(new Customer("Ankit","Singh"));
		
		//Display customer details
		System.out.println("---------------------");
		System.out.println("Customers Details");
	    System.out.println("---------------------");
	    for (Customer customer : repository.findAll()) {
	      System.out.println(customer);
	    }
		
	}
}
