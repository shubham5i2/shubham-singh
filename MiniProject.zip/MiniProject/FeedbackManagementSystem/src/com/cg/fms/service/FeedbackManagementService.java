package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.dao.FeedbackManagementDao;
import com.cg.fms.dao.IFeedbackManagementDao;

public class FeedbackManagementService implements IFeedbackManagementService{
	
	@Override
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID,String employeePass) {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> arrayList=new ArrayList<FeedackManagementBean>();
		arrayList=dao.retrieveDetails(employeeID,employeePass);
		return arrayList;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		skillList=dao.retrieveFacultyDetails();
		return skillList;
	}
	
	@Override
	public boolean updateFacultyDetails(int employeeId,String skills) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.updateFacultyDetails(employeeId,skills);
		return result;
	}
	
	@Override
	public boolean deleteFaculty(int deleteFacultyID) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.deleteFaculty(deleteFacultyID);
		return result;
	}

	@Override
	public ArrayList<FeedackManagementBean> retrieveCourseDetails() {
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
		courseList=dao.retrieveCourseDetails();
		return courseList;
	}

	@Override
	public boolean addFeedbackDetails(int employeeID,int presComm, int clrDbts, int tm,int hndout, int hsn,String comments,String sugg) {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.addFeedbackDetails(employeeID,presComm, clrDbts, tm, hndout, hsn,comments,sugg);
		return result;
	}

	@Override
	public boolean viewFeedbackDetails() {
		boolean result=false;
		IFeedbackManagementDao dao=new FeedbackManagementDao();
		result=dao.viewFeedbackDetails();
		return result;
	}

}
